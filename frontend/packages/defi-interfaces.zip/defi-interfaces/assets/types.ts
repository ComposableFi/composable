// Auto-generated via `yarn polkadot-types-from-defs`, do not edit
/* eslint-disable */

export type PHANTOM_ASSETS = 'assets';
