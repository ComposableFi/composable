// Auto-generated via `yarn polkadot-types-from-chain`, do not edit
/* eslint-disable */

import '@polkadot/api/augment/rpc';
import './augment-api-consts';
import './augment-api-errors';
import './augment-api-events';
import './augment-api-query';
import './augment-api-tx';
import './augment-api-rpc';
