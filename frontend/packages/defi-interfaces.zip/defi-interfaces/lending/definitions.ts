export default {
  rpc: {},
  types: {}
};
